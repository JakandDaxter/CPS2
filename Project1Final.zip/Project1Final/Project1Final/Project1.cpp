//=========================================================================================//
// Programmer  : Aliana Tejeda
// File Name   : Project 1.cpp
// course      : Computational Problem Solving II - CPET
// DateCreated : 9/11/2017
// Description : A four function Complex Calculator
//=========================================================================================//
// ( )_( )
// (='.'=)('') <-- Bunny
// ( )_( )

#include <iostream>
#include <cstring>
#include <iomanip>
#include <cmath>


using namespace std;

//class

class ComplexNumber
    {
    
        private:
            double Areal, Aimaginary;
            double distance,theta;
            char Datatype;
    
    
    
    
    
        public:
    
    friend int main();//lets the main function access the private
    
    ComplexNumber(float a = 0.0, float b = 0.0, float d = 0.0, float e = 0.0, char f ='V')
                    {Areal = a; Aimaginary = b; distance = d; theta = e; Datatype = f;}
        
    void PolarForm();
    void RectangularForm();
    
    void SecureData(float,float,float,float);
    
    ComplexNumber operator+(const ComplexNumber&); //prototype for addition operator
    ComplexNumber operator-(const ComplexNumber&); //prototype for subtraction operator
    ComplexNumber operator*(const ComplexNumber&); //prototype for multiplication operator
    ComplexNumber operator/(const ComplexNumber&); //prototype for division operator
    
    ComplexNumber swapy(ComplexNumber&, ComplexNumber&);
    
    
    
};
//Implementation


void ComplexNumber::SecureData(float a1 ,float a2 ,float b1 , float b2)
{
    Areal=a1;
    Aimaginary=a2;
    
    distance=b1;
    theta=b2;
}//incase i do need the original data it is here


ComplexNumber ComplexNumber::operator+(const ComplexNumber& ComplexNumber2)
{
    ComplexNumber temp;
    temp.Areal = Areal + ComplexNumber2.Areal;
    temp.Aimaginary = Aimaginary + ComplexNumber2.Aimaginary;
    
    return temp;
}
ComplexNumber ComplexNumber::operator-(const ComplexNumber& ComplexNumber2)
{
    ComplexNumber temp;
    temp.Areal = Areal - ComplexNumber2.Areal;
    temp.Aimaginary = Aimaginary - ComplexNumber2.Aimaginary;
    
    return temp;
}
ComplexNumber ComplexNumber::operator*(const ComplexNumber& ComplexNumber2)//subtraction operator
{
    
    ComplexNumber temp;
    temp.Areal = (Areal * ComplexNumber2.Areal) - (Aimaginary * ComplexNumber2.Aimaginary);
    temp.Aimaginary = (Areal * ComplexNumber2.Aimaginary) + (Aimaginary* ComplexNumber2.Areal);
    
    return temp;
}
ComplexNumber ComplexNumber::operator/(const ComplexNumber& ComplexNumber2)//subtraction operator
{
    
    ComplexNumber temp;
    
    temp.Areal = ((Areal*ComplexNumber2.Areal)+(Aimaginary*ComplexNumber2.Aimaginary))/((ComplexNumber2.Areal*ComplexNumber2.Areal)+(ComplexNumber2.Aimaginary*ComplexNumber2.Aimaginary));
    
    temp.Aimaginary = ((Aimaginary*ComplexNumber2.Areal)-(Areal*ComplexNumber2.Aimaginary))/((ComplexNumber2.Areal*ComplexNumber2.Areal)+(ComplexNumber2.Aimaginary*ComplexNumber2.Aimaginary));
    
    return temp;
}

ComplexNumber ComplexNumber::swapy(ComplexNumber& T1, ComplexNumber& T2)
{
    ComplexNumber temp = T1;
    T1 = T2;
    T2 = temp;
    
    return T1;
}

void ComplexNumber::PolarForm()//Rectangular to Polar
{
    
    double ToDegrees = 180/3.141593;//converts angle to degrees
    
    distance = sqrt((pow(Areal,2))+(pow(Aimaginary,2)));
    theta = atan(Aimaginary/Areal)*ToDegrees;
    char sign = '+';
    if (theta<0) sign ='-';//for negative values
    cout << "\n  Polar Form: " << distance << " < " << sign << abs(theta);
    
}
void ComplexNumber::RectangularForm()//Polar to rectangular
{
    theta = (theta*3.141592654)/180;//converts angle to radians
    Areal = distance * cos( theta );
    Aimaginary = distance * sin( theta );
    
    char sign = '+';
    if (Aimaginary < 0) sign = '-';
    if (Areal < 0) sign = '-';
    cout <<"\n  Rectangular Form: "  << Areal << ' ' << sign << ' '<<(Aimaginary) << 'i';
}



int main()

{   char signtype;
    int choice = 0;
    ComplexNumber c1,c2,d;
    
    cout << "\nWelcome To The Four Function Complex Calcultor\n";
    
    cout << "\nThis Current Edition of the Calculator Only Supports Two Complex Values to Be Manipulated\n";
    
    cout << "\nHere is your menu\n";
    
    cout <<endl;
    
    cout<<"\n1.  Enter Calculator World\n";
    
    cout<<"\n10. Exit \n\n";
    
    cout<<"Enter Your Desired Numbered Choice Here:";cin>>choice;cout<<endl;cout<<endl;
    
    {if (choice == 10) //safety net to make sure the menue actually exit
    {return(0);}}//Safe Net to Exit
    
    
    while( choice >0 && choice <=10)
    {
        {
            cout << "\nHere is your menu\n";
            
            cout << endl;
            
            cout<<"\n1. Addition\n";
            
            cout<<"\n2. Subtraction\n";
            
            cout<<"\n3. Multiplication\n";
            
            cout<<"\n4. Division\n";
            
            cout<<"\n5. Swap Values\n";
            
            cout<<"\n6. Move Answer To Variable A\n";
            
            cout<<"\n7. Move Answer To Variable B\n";
            
            cout<<"\n8. Enter Complex Value To Variable A\n";
            
            cout<<"\n9. Enter Complex Value To Variable B\n";
            
            cout<<"\n10. Exit \n";
            cout<<endl;
            cout<<" Enter Your Desired Numbered Choice Here:";cin>>choice;cout<<endl;cout<<endl;
        
        }//Menue
        
        switch(choice)//choices
        {
            case 1:
                d= c1 + c2;
                cout<<"\n The sum of A and B: ";
                
                d.PolarForm();
                d.RectangularForm();cout<<endl;cout<<endl;
                break;
                
            case 2:
                d= c1 - c2;
                cout<<"\n The difference of A and B : ";
                d.PolarForm();
                d.RectangularForm();cout<<endl;cout<<endl;
                break;
                
            case 3:
                d= c1 * c2;
                cout<<"\n The product of A and B : ";
                d.PolarForm();
                d.RectangularForm();cout<<endl;cout<<endl;
                break;
                
            case 4:
                d= c1 / c2;
                cout<<"\n The quotient of A and B : ";
                d.PolarForm();
                d.RectangularForm();cout<<endl;cout<<endl;
                break;
                
            case 5:
                cout<<"\n The New Home of A Value: ";
                c2.PolarForm();
                c2.RectangularForm();
                cout<<"\n The New Home of B value: ";
                c1.PolarForm();
                c1.RectangularForm();cout<<endl;cout<<endl;
                
                break;
                
            case 6:
                cout<<"\n A : ";
                swap(d,c1);
                c1.PolarForm();
                c1.RectangularForm();cout<<endl;cout<<endl;
                break;
                
            case 7:
                cout<<"\n B : ";
                swap(d,c2);
                c2.PolarForm();
                c2.RectangularForm();cout<<endl;cout<<endl;
                break;
                
            case 8:
                cout<<"What type you want,to chose rectangular (r) polar (p) type letter "<<endl;
                cin>> signtype;
                switch (signtype)
            {
                case 'r':
                    
                    cout<<"\n Enter Rectangular data for  A ";
                    cin>> c1.Areal;
                    cin>>c1.Aimaginary;
                    c1.PolarForm();
                    c1.RectangularForm();
                    cout<<endl;cout<<endl;
                    break;
                case 'p':
                    cout<<"\n Enter Polar data for A As so : R theta\n";cout<<endl;
                    cin>>c1.distance;
                    cin>>c1.theta;
                    c1.RectangularForm();
                    c1.PolarForm();
                    cout<<endl;cout<<endl;
                    break;
                default:
                    cout<<"You messed up and entered the wrong value";
                    cout<<"\n Enter (r) for rectangular or (p) for polar";
            }
                
                break;
                
            case 9:
                
                cout<<"What type you want,to chose rectangular (r) polar (p) type letter "<<endl;
                cin>> signtype;
                switch (signtype)
            {
                case 'r':
                    cout<<"\n Enter Rectangular data for (B)";
                    cin>>c2.Areal;
                    cin>>c2.Aimaginary;
                    c2.PolarForm();
                    c2.RectangularForm();
                    cout<<endl;cout<<endl;
                    break;
                case 'p':
                    cout<<"\nEnter Polar data for A As so : R theta \n";cout<<endl;
                    cin>>c2.distance;
                    cin>>c2.theta;
                    c2.RectangularForm();
                    c2.PolarForm();
                    cout<<endl;cout<<endl;
                    break;
                default:
                    cout<<"You messed up and entered the wrong value";
                    cout<<"\n Enter (r) for rectangular or (p) for polar";
            }
                break;
                
                
            case 10:
                cout<<"\n Peace Out \n\n";
                return(0);
                break;
                
        }
        
    }
}





