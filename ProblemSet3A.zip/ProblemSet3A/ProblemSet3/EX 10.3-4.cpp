//=========================================================================================//
// Programmer  : Aliana Tejeda
// File Name   : EX 10.3-4.cpp
// course      : Computational Problem Solving II - CPET
// Date        : 10/25/2017
// Description : a program that declares three one-dimensional arrays named miles, gallons, and mpg. Each array holds 10 elements, and each element of the mpg array is calculated as the corresponding element of the miles array divided by the equivalent element of the gallons array using pointers.
//=========================================================================================//
// ( )_( )
// (='.'=)('') <-- Bunny
// ( )_( )

#include <iostream>
#include <iomanip>
using namespace std;

//******************************************************//
//                     Int Main                         //
//******************************************************//
int main(int argc, const char * argv[])
{
    float miles[10]= {240.5 , 300.0 , 189.6 , 310.6 , 280.7 , 216.9 , 19.4, 160.3, 177.4, 192.3};
    float gallons[10]= {10.3 , 15.6 , 8.7 , 14 , 16.3 , 15.7 , 14.9, 10.7, 8.3, 8.4};

    float mpg[10]={};


    for(int i=0; i<9; i++)
    {
        mpg[i] = miles[i] / gallons[i];

        cout<<"MPG"<<i<< " = "<<(mpg[i])<<endl<<endl;

    }
}








