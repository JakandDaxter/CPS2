//=========================================================================================//
// Programmer  : Aliana Tejeda
// File Name   : EX 10.6-5.cpp
// course      : Computational Problem Solving II - CPET
// Date        : 10/25/2017
// Description : A program that declares three one-dimensional arrays named current, resistance, and voltage. Each array is declared in main() and  holds 10 double-precision numbers.The program passed three arrays to a function called calcVolts(), which calculates the elements in the voltage array as the product of the equivalent elements in the current and resistance arrays.
//=========================================================================================//
// ( )_( )
// (='.'=)('') <-- Bunny
// ( )_( )

#include <iostream>
#include <iomanip>
using namespace std;
/******************************************************//
//                     Just the size                    //
//******************************************************//
const int parameter = 10;
//float calcVolts(float voltage[parameter],float current[parameter],float resistance[parameter]);

//******************************************************//
//                Function Prototype                    //
//******************************************************//
double calcVolts(double[],double[],double[]);
//******************************************************//
//                     int Main                         //
//******************************************************//
int main(int argc, const char * argv[])
{
    double current[parameter]= {10.62 , 14.89 , 13.21 , 16.55 ,  18.62, 9.47 , 6.58, 18.32, 12.15, 3.98};

    double resistance[parameter]= {4 , 8.5, 6, 7.35, 9, 15.3, 3, 5.4, 2.9, 4.8};

    double voltage[parameter];

    calcVolts(voltage, current, resistance);

    return(0);
}

//*******************************************************************************************************************************//
//      double function that calculates voltage and sets the data in each respected memory location of array in the for loop     //
//*******************************************************************************************************************************//
double calcVolts(double voltage[],double current[],double resistance[])
{
    for(int i=0; i<10; i++)
    {
        voltage[i] = current[i] * resistance[i];
        cout<<"Voltage"<<i<< " = "<<*(voltage + i)<<endl<<endl;
    }
    return(0);
}
