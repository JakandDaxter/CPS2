//=========================================================================================//
// Programmer  : Aliana Tejeda
// File Name   : EX 10.3-3.cpp
// course      : Computational Problem Solving II - CPET
// Date        : 10/25/2017
// Description :  A program that stores the following numbers in the array named miles.program copy the data stored in miles to another array named dist, and then display the values in the  pointer dist array
//=========================================================================================//
// ( )_( )
// (='.'=)('') <-- Bunny
// ( )_( )

#include <iostream>
#include <iomanip>
using namespace std;
//******************************************************//
//                     int Main                         //
//******************************************************//
int main(int argc, const char * argv[])
{
    int miles[7]= {15 , 22 , 16 , 18 , 27 , 23 ,20};
    int *dist;

    dist = &miles[0];

    //******************************************************//
    //                Goes through array                    //
    //******************************************************//
    for(int i=0; i<7; i++)
        cout<<"distance"<<i<< " = "<<*(dist + i)<<endl<<endl;
    

    return(0);
}
