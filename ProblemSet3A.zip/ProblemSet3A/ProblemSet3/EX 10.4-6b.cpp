//=========================================================================================//
// Programmer  : Aliana Tejeda
// File Name   : EX 10.4-6b.cpp
// course      : Computational Problem Solving II - CPET
// Date        : 10/25/2017
// Description : Modified code from EX 10.4-6b.cpp that has the show() function written in Exercise 6a, the address however is edited in the for loop.
//=========================================================================================//
// ( )_( )
// (='.'=)('') <-- Bunny
// ( )_( )

#include <iostream>
#include <iomanip>
using namespace std;
//******************************************************//
//                     Just the size                    //
//******************************************************//
const int parameter = 9;
//******************************************************//
//                Function Prototype                    //
//******************************************************//
float ShowData(float rates[parameter]);

//******************************************************//
//                     int Main                         //
//******************************************************//
int main(int argc, const char * argv[])
{
    float rates[parameter]= {6.5 , 7.2 , 7.5 , 8.3 ,  8.6, 9.4 , 9.6, 9.8, 10.0};



    ShowData(rates);

    return(0);
}

//**********************************************************************************************************************//
//      Float function that displays array elements passed through different use of stepping through array elements     //
//**********************************************************************************************************************//
float ShowData(float rates[parameter])
{


    for(int i=0; i<9; i++, rates++)
    {


        cout<<"RATE"<<i<< " = "<<*rates<<endl<<endl;

    }
    return(0);
}
