//=========================================================================================//
// Programmer  : Aliana Tejeda
// File Name   : EX 10.4-6a.cpp
// course      : Computational Problem Solving II - CPET
// Date        : 10/25/2017
// Description : a program that has a declaration in main() to store 9 numbers in an array named rates. It includes a function called show() that accepts rates in a parameter named rates and then displays the numbers by using the pointer notation *(rates + i).
//=========================================================================================//
// ( )_( )
// (='.'=)('') <-- Bunny
// ( )_( )

#include <iostream>
#include <iomanip>
using namespace std;
//******************************************************//
//                     Just the size                    //
//******************************************************//
const int parameter = 9;
//******************************************************//
//                Function Prototype                    //
//******************************************************//
float ShowData(float rates[parameter]);

//******************************************************//
//                     int Main                         //
//******************************************************//
int main(int argc, const char * argv[])
{
    float rates[parameter]= {6.5 , 7.2 , 7.5 , 8.3 ,  8.6, 9.4 , 9.6, 9.8, 10.0};


    ShowData(rates);

    return(0);
}
//************************************************************//
//  Float function that displays array elements passed through//
//************************************************************//
float ShowData(float rates[parameter])
{

    float potato;
    for(int i=0; i<9; i++)
    {
        potato =*(rates+ i);

        cout<<"RATE"<<i<< " = "<<potato<<endl<<endl;

    }
    return(0);
}

